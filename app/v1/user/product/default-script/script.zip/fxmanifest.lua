fx_version "adamant"
game "gta5"
lua54 "yes"

script_version "1.0.0"

server_scripts {"auth/authorization.lua"}
shared_scripts {"auth/config.lua"}
client_scripts {}